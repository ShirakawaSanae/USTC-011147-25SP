package com.rabbiter.library.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.rabbiter.library.annotation.Auth;
import com.rabbiter.library.utils.ResultUtils;
import com.rabbiter.library.utils.ResultVo;
import com.rabbiter.library.dto.CategoryEcharts;
import com.rabbiter.library.dto.ListCateParm;
import com.rabbiter.library.entity.SysCategory;
import com.rabbiter.library.service.SysCategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/category")
public class SysCategoryController {
    @Autowired
    private SysCategoryService sysCategoryService;

    //新增
    @Auth
    @PostMapping
    public ResultVo add(@RequestBody SysCategory category){
        boolean save = sysCategoryService.save(category);
        if(save){
            return ResultUtils.success("新增成功!");
        }
        return ResultUtils.error("新增失败!");
    }

    //编辑
    @Auth
    @PutMapping
    public ResultVo edit(@RequestBody SysCategory category){
        boolean save = sysCategoryService.updateById(category);
        if(save){
            return ResultUtils.success("编辑成功!");
        }
        return ResultUtils.error("编辑失败!");
    }

    //删除
    @Auth
    @DeleteMapping("/{categoryId}")
    public ResultVo delete(@PathVariable("categoryId") Long categoryId){
        boolean remove = sysCategoryService.removeById(categoryId);
        if(remove){
            return ResultUtils.success("删除成功!");
        }
        return ResultUtils.error("删除失败!");
    }

    //列表
    @Auth
    @GetMapping("/list")
    public ResultVo getList(ListCateParm parm){
        IPage<SysCategory> list = sysCategoryService.getList(parm);
        return ResultUtils.success("查询成功",list);
    }

    //图书列表分类
    @Auth
    @GetMapping("/cateList")
    public ResultVo getCateList(){
        List<SysCategory> list = sysCategoryService.list();
        return ResultUtils.success("查询成功",list);
    }

    //图书列表分类
    @Auth
    @GetMapping("/categoryCount")
    public ResultVo categoryCount(){
        CategoryEcharts categoryVo = sysCategoryService.getCategoryVo();
        return ResultUtils.success("查询成功",categoryVo);
    }
}
