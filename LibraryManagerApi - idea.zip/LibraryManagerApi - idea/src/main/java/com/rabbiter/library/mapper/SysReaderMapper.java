package com.rabbiter.library.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.rabbiter.library.entity.SysReader;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SysReaderMapper extends BaseMapper<SysReader> {

    int updateAvatarById(Integer readerId, String avatarUrl);
    SysReader selectById(Integer readerId);  // 用于读取头像
}

