package com.rabbiter.library.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.rabbiter.library.dto.ReaderParm;
import com.rabbiter.library.entity.SysReader;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

public interface SysReaderService extends IService<SysReader> {
    IPage<SysReader> getList(ReaderParm parm);
    //新增读者
    void saveReader(SysReader sysReader);
    //编辑读者
    void editReader(SysReader sysReader);

    SysReader loadByUsername(String username);

    //String saveAvatar(MultipartFile file, Integer userId) throws IOException;

    boolean updateAvatar(Integer readerId, String avatarUrl);
    SysReader getById(Integer readerId);
    String saveAvatar(MultipartFile file, Integer userId) throws Exception;
}
