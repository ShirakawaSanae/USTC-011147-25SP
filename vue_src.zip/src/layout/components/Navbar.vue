<template>
  <div class="navbar">
    <hamburger
      :is-active="sidebar.opened"
      class="hamburger-container"
      @toggleClick="toggleSideBar"
    />

    <breadcrumb class="breadcrumb-container"/>

    <div class="right-menu">
      <el-dropdown class="avatar-container" trigger="click">
        <div class="avatar-wrapper">
          <img :src="avatarUrl || require('@/assets/images/avatar.jpg')" class="user-avatar" style="border: 1px solid grey;border-radius: 10px;" />
          <i class="el-icon-caret-bottom"/>
        </div>
        <el-dropdown-menu slot="dropdown" class="user-dropdown">
          <router-link to="/">
            <el-dropdown-item> 首页</el-dropdown-item>
          </router-link>
          <el-dropdown-item divided @click.native="updatePwd">
            <span style="display: block">密码修改</span>
          </el-dropdown-item>
          <el-dropdown-item divided @click.native="logout">
            <span style="display: block">退出登录</span>
          </el-dropdown-item>
          <el-dropdown-item divided @click.native="showAvatarDialog = true">
            <span style="display: block">更换头像</span>
          </el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>
    </div>
    <!-- 修改密码弹框 -->
    <sys-dialog
      :title="dialog.title"
      :height="dialog.height"
      :width="dialog.width"
      :visible="dialog.visible"
      @onClose="onClose"
      @onConfirm="onConfirm"
    >
      <div slot="content">
        <el-form
          :model="addModel"
          ref="addModel"
          :rules="rules"
          label-width="80px"
          :inline="true"
           
        >
          <el-form-item prop="oldPassword" label="原密码">
            <el-input v-model="addModel.oldPassword" type="password"></el-input>
          </el-form-item>
          <el-form-item prop="password" label="新密码">
            <el-input v-model="addModel.password" type="password"></el-input>
          </el-form-item>
        </el-form>
      </div>
    </sys-dialog>
    <el-dialog title="更换头像" :visible.sync="showAvatarDialog" width="30%">
      <div style="text-align: center;">
        <img :src="previewAvatar || avatarPath" class="user-avatar" style="width: 100px; height: 100px; margin-bottom: 10px;" />
        <el-upload
          class="upload-demo"
          action="/api/uploadAvatar"
          :show-file-list="false"
          :on-success="handleAvatarSuccess"
          :before-upload="beforeAvatarUpload"
          :auto-upload="true"
          :on-change="handleFileChange"
        >
          <el-button size="small" type="primary">点击上传头像</el-button>
        </el-upload>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import SysDialog from '@/components/dialog/SysDialog.vue'
import { mapGetters } from 'vuex'
import Breadcrumb from '@/components/Breadcrumb'
import Hamburger from '@/components/Hamburger'
import { updatePasswordApi } from '@/api/user'
import { getAvatarApi } from '@/api/reader'
import { getUserId } from '@/utils/auth'

export default {
  components: {
    Breadcrumb,
    Hamburger,
    SysDialog
  },
  data() {
    return {
      avatarUrl: require('@/assets/images/avatar.jpg'), // 默认头像
      rules: {
        oldPassword: [
          { trigger: 'blur', required: true, message: '原密码不能为空!' }
        ],
        password: [
          { trigger: 'blur', required: true, message: '新密码不能为空!' }
        ]
      },
      addModel: {
        userId: '',
        oldPassword: '',
        password: '',
        learnNum: ''
      },
      dialog: {
        title: '密码修改',
        height: 150,
        width: 650,
        visible: false
      }
    }
  },
  computed: {
    ...mapGetters(['sidebar', 'avatar'])
  },
  methods: {
    onConfirm() {
      this.$refs.addModel.validate(async(valid) => {
        if (valid) {
          this.addModel.userId = getUserId()
          let res = await updatePasswordApi(this.addModel)
          if (res && res.code == 200) {
            this.$message.success(res.msg)
            this.dialog.visible = false
          }
        }
      })
    },
    onClose() {
      this.dialog.visible = false
    },
    updatePwd() {
      this.dialog.visible = true
    },
    toggleSideBar() {
      this.$store.dispatch('app/toggleSideBar')
    },
    async logout() {
      await this.$store.dispatch('user/logout')
      this.$router.push(`/login?redirect=${this.$route.fullPath}`)
    },
    async loadUserAvatar() {
      const res = await getAvatarApi() // 调用后端接口返回 sys_reader 信息
      if (res && res.code === 200 && res.data.avatar) {
        this.avatarUrl = res.path
      }
    },
    handleAvatarSuccess(res) {
      if (res.code === 200) {
        this.$message.success('头像上传成功！');
        // 更新前端头像路径
        this.$store.commit('user/SET_AVATAR', res.path);
        this.avatarUrl = res.path
        // this.avatarUrl = res.path;
        this.$forceUpdate(); // 强制刷新组件
         this.showAvatarDialog = false;
      } else {
        this.$message.error('上传失败');
      }
    },
    beforeAvatarUpload(file) {
      const isJPG = file.type === 'image/jpeg' || file.type === 'image/png';
      const isLt2M = file.size / 1024 / 1024 < 2;

      if (!isJPG) {
        this.$message.error('只能上传 JPG/PNG 格式!');
      }
      if (!isLt2M) {
        this.$message.error('头像大小不能超过 2MB!');
      }
      return isJPG && isLt2M;
    }
  }
}
</script>

<style lang="scss" scoped>
.navbar {
  height: 70px;
  overflow: hidden;
  position: relative;
  background: #fff;
  box-shadow: 0 1px 4px rgba(0, 21, 41, 0.08);

  .hamburger-container {
    line-height: 46px;
    height: 100%;
    float: left;
    cursor: pointer;
    transition: background 0.3s;
    -webkit-tap-highlight-color: transparent;
    &:hover {
      background: rgba(0, 0, 0, 0.025);
    }
  }

  .breadcrumb-container {
    float: left;
  }

  .right-menu {
    float: right;
    height: 100%;
    line-height: 50px;

    &:focus {
      outline: none;
    }

    .right-menu-item {
      display: inline-block;
      padding: 0 8px;
      height: 100%;
      font-size: 18px;
      color: #5a5e66;
      vertical-align: text-bottom;

      &.hover-effect {
        cursor: pointer;
        transition: background 0.3s;

        &:hover {
          background: rgba(0, 0, 0, 0.025);
        }
      }
    }

    .avatar-container {
      margin-right: 30px;

      .avatar-wrapper {
        margin-top: 5px;
        position: relative;

        .user-avatar {
          cursor: pointer;
          width: 60px;
          height: 60px;
          border-radius: 10px;
        }

        .el-icon-caret-bottom {
          cursor: pointer;
          position: absolute;
          right: -20px;
          top: 25px;
          font-size: 12px;
        }
      }
    }

    .avatar-uploader .el-upload {
      border: 1px dashed #d9d9d9;
      border-radius: 6px;
      cursor: pointer;
      position: relative;
      overflow: hidden;
    }
    .avatar-uploader .el-upload:hover {
      border-color: #409EFF;
    }
    .avatar-uploader-icon {
      font-size: 28px;
      color: #8c939d;
      width: 100px;
      height: 100px;
      line-height: 100px;
      text-align: center;
    }
    .avatar {
      width: 100px;
      height: 100px;
      display: block;
    }



  }
}
</style>
